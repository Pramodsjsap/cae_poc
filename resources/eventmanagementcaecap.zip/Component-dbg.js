sap.ui.define(['sap/fe/core/AppComponent'], function(AppComponent) {
    'use strict';

    return AppComponent.extend("eventmanagementcaecap.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
